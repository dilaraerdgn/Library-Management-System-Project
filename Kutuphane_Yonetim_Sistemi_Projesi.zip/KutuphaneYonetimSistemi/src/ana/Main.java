package ana;

import kullaniciyonetimi.GirisYapma;
import kullaniciyonetimi.KayitOlma;
import kullaniciyonetimi.VeritabaniKullanicilarTablosu;
import kitapyonetimi.KitapArama;
import kitapyonetimi.KitapEkleme;
import kitapyonetimi.KitapGuncelleme;
import kitapyonetimi.VeritabaniKitaplarTablosu;
import oduncislemleri.KitapIadeEtme;
import oduncislemleri.KitapOduncAlma;
import oduncislemleri.OduncListesiniGosterme;
import oduncislemleri.VeritabaniOdunclarTablosu;
import bildirimsistemi.BildirimGonderme;
import bildirimsistemi.VeritabaniBildirimlerTablosu;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        VeritabaniKullanicilarTablosu veritabaniKullanicilarTablosu=new VeritabaniKullanicilarTablosu();
        GirisYapma girisYapma=new GirisYapma();
        KayitOlma kayitOlma=new KayitOlma();
        VeritabaniKitaplarTablosu veritabaniKitaplarTablosu=new VeritabaniKitaplarTablosu();
        KitapArama kitapArama=new KitapArama();
        KitapEkleme kitapEkleme=new KitapEkleme();
        KitapGuncelleme kitapGuncelleme=new KitapGuncelleme();
        VeritabaniOdunclarTablosu veritabaniOdunclarTablosu=new VeritabaniOdunclarTablosu();
        KitapOduncAlma kitapOduncAlma=new KitapOduncAlma();
        KitapIadeEtme kitapIadeEtme=new KitapIadeEtme();
        OduncListesiniGosterme oduncListesiniGosterme=new OduncListesiniGosterme();
        VeritabaniBildirimlerTablosu veritabaniBildirimlerTablosu=new VeritabaniBildirimlerTablosu();
        BildirimGonderme bildirimGonderme=new BildirimGonderme();
        
        System.out.println("=== KÜTÜPHANE YÖNETİM SİSTEMİ ===\n");
        System.out.println("***Giriş Ekranı***");
        System.out.print("Kullanıcı adı giriniz: ");
        String kullaniciAdi = giris.nextLine();
        System.out.print("Şifre giriniz: ");
        String sifre = giris.nextLine();
        
        
        if (!girisYapma.girisYap(kullaniciAdi, sifre)) {
            System.out.println("Kullanıcı bulunamadı. Kayıt olmak isterseniz mail adresinizi giriniz..");
            System.out.print("Mail adresi giriniz: ");
            String mailAdresi = giris.nextLine();
            kayitOlma.kaydol(kullaniciAdi, sifre, mailAdresi);
        }

        
        boolean devam = true;
        while (devam) {
            System.out.println("\n=== MENÜ ===");
            System.out.println("1- Kitap Ekle");
            System.out.println("2- Kitap Ara");
            System.out.println("3- Kitap Ödünç Al");
            System.out.println("4- Kitap İade Et");
            System.out.println("5- Ödünç Listesini Görüntüle");
            System.out.println("6- Kitap Bilgilerini Güncelle");
            System.out.println("7- Bildirim Gönder");
            System.out.println("0- Çıkış");
            System.out.print("Seçiminiz: ");

            int secim = giris.nextInt();
            giris.nextLine(); 

            switch (secim) {
                case 1:
                    System.out.print("Kitap adı: ");
                    String kitapAdi = giris.nextLine();
                    System.out.print("Yazar: ");
                    String yazar = giris.nextLine();
                    System.out.print("Tür: ");
                    String tur = giris.nextLine();
                    System.out.print("Yayin Yılı: ");
                    String yayinyili = giris.nextLine();
                    kitapEkleme.kitapEkle(kitapAdi, yazar,tur,yayinyili);
                    break;
                case 2:
                	System.out.print("Aramak istediğiniz kelimeyi girin (kitap adı, yazar, tür vs.): ");
                	String anahtarKelime = giris.nextLine();
                	kitapArama.kitapAra(anahtarKelime);
                    break;
                case 3:
                    System.out.print("Ödünç alınacak kitap ID: ");
                    int kitapId = giris.nextInt();
                    System.out.print("Ödünç alan kullanıcının ID: ");
                    int kullaniciId = giris.nextInt();
                    kitapOduncAlma.kitapOduncAl(kullaniciId, kitapId);
                    break;
                case 4:
                    System.out.print("İade edilecek ödünç ID: ");
                    int oduncId = giris.nextInt();
                    kitapIadeEtme.kitapIadeEt(oduncId);
                    break;
                case 5:
                    oduncListesiniGosterme.oduncListesiniGoster();
                    break;
                case 6:
                	System.out.print("Güncellenecek kitap ID: ");
                    int guncelleId = giris.nextInt();
                    giris.nextLine(); 
                    System.out.print("Yeni kitap adı: ");
                    String yeniAd = giris.nextLine();
                    System.out.print("Yeni yazar adı: ");
                    String yeniYazar = giris.nextLine();
                    System.out.print("Yeni tür: ");
                    String yeniTur = giris.nextLine();
                    System.out.print("Yeni yayın yılı: ");
                    String yeniYayinYili = giris.nextLine();
                    kitapGuncelleme.kitapGuncelle(guncelleId, yeniAd, yeniYazar, yeniTur, yeniYayinYili);
                	break;
                case 7:
                    System.out.print("Bildirim mesajı: ");
                    String mesaj = giris.nextLine();
                    System.out.println("Hangi kullanıcıya bildirim gönderilecek...");
                    int bildirimId = giris.nextInt();
                    bildirimGonderme.bildirimGonder(bildirimId, mesaj);
                    break;
                case 0:
                    devam = false;
                    System.out.println("Çıkış yapılıyor...");
                    break;
                default:
                    System.out.println("Geçersiz seçim, tekrar deneyin.");
                    break;
            }
        }

        giris.close();
    }
}
