package bildirimsistemi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

import veritabani.VeritabaniBaglantisi;

public class BildirimGonderme implements IBildirimGonderme{
	
	@Override
    public void bildirimGonder(int kullaniciId, String mesaj) {
        String sql = "INSERT INTO bildirimler (kullanici_id, mesaj, gonderim_zamani) VALUES (?, ?, ?)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, kullaniciId);
            pstmt.setString(2, mesaj);
            pstmt.setString(3, LocalDateTime.now().toString());
            pstmt.executeUpdate();
            System.out.println("Bildirim gönderildi (simülasyon): " + mesaj + " -> Kullanıcı ID: " + kullaniciId);
        } catch (SQLException e) {
            System.out.println("Bildirim gönderilirken hata: " + e.getMessage());
        }
    }
}
