package bildirimsistemi;

public interface IBildirimGonderme {
	void bildirimGonder(int kullaniciId, String mesaj);
}
