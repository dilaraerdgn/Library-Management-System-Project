package bildirimsistemi;

import veritabani.VeritabaniBaglantisi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VeritabaniBildirimlerTablosu {

    public VeritabaniBildirimlerTablosu() {
        tabloOlustur();
    }

    private void tabloOlustur() {
        String sql = "CREATE TABLE IF NOT EXISTS bildirimler (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "kullanici_id INTEGER," +
                     "mesaj TEXT," +
                     "gonderim_zamani TEXT)";
        
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Bildirimler tablosu oluşturulurken hata: " + e.getMessage());
        }
    }

    
}