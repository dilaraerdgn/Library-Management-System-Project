package kitapyonetimi;

public interface IKitapArama {
	void kitapAra(String anahtarKelime);
}
