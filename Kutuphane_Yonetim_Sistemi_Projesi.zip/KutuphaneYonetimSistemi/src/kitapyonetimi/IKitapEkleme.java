package kitapyonetimi;

public interface IKitapEkleme {
	void kitapEkle(String ad, String yazar, String tur, String yayinYili);
}
