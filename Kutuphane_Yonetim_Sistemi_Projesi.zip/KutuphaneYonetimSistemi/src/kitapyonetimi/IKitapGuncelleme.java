package kitapyonetimi;

public interface IKitapGuncelleme {
	void kitapGuncelle(int id, String yeniAd, String yeniYazar, String yeniTur, String yeniYayinYili);
}
