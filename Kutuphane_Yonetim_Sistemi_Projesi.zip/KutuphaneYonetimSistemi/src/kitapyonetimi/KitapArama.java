package kitapyonetimi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class KitapArama implements IKitapArama {
	
	@Override
    public void kitapAra(String anahtarKelime) {
        String sql = "SELECT * FROM kitaplar WHERE ad LIKE ? OR yazar LIKE ?";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + anahtarKelime + "%");
            pstmt.setString(2, "%" + anahtarKelime + "%");
            ResultSet rs = pstmt.executeQuery();
            boolean bulunduMu = false;
            while (rs.next()) {
                bulunduMu = true;
                System.out.println("Bulunan Kitap - ID: " + rs.getInt("id") +
                                   ", Ad: " + rs.getString("ad") +
                                   ", Yazar: " + rs.getString("yazar") +
                                   ", Tür: " + rs.getString("tur") +
                                   ", Yayın Yılı: " + rs.getInt("yayin_yili"));
            }
            if (!bulunduMu) {
                System.out.println("Aradığınız kriterlere uygun kitap bulunamadı.");
            }
        } catch (SQLException e) {
            System.out.println("Kitap aranırken hata: " + e.getMessage());
        }
    }

}
