package kitapyonetimi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class KitapEkleme implements IKitapEkleme{
	
	@Override
    public void kitapEkle(String ad, String yazar, String tur, String yayinYili) {
        String sql = "INSERT INTO kitaplar (ad, yazar, tur, yayin_yili) VALUES (?, ?, ?, ?)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ad);
            pstmt.setString(2, yazar);
            pstmt.setString(3, tur);
            pstmt.setString(4, yayinYili);
            pstmt.executeUpdate();
            System.out.println("Kitap eklendi: " + ad);
        } catch (SQLException e) {
            System.out.println("Kitap eklenirken hata: " + e.getMessage());
        }
    }
}
