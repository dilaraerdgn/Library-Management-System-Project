package kitapyonetimi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class KitapGuncelleme implements IKitapGuncelleme{
	
	@Override
    public void kitapGuncelle(int id, String yeniAd, String yeniYazar, String yeniTur, String yeniYayinYili) {
        String sql = "UPDATE kitaplar SET ad = ?, yazar = ?, tur = ?, yayin_yili = ? WHERE id = ?";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, yeniAd);
            pstmt.setString(2, yeniYazar);
            pstmt.setString(3, yeniTur);
            pstmt.setString(4, yeniYayinYili);
            pstmt.setInt(5, id);
            int guncellenenSatir = pstmt.executeUpdate();
            if (guncellenenSatir > 0) {
                System.out.println("Kitap güncellendi: ID = " + id);
            } else {
                System.out.println("Kitap bulunamadı: ID = " + id);
            }
        } catch (SQLException e) {
            System.out.println("Kitap güncellenirken hata: " + e.getMessage());
        }
    }
}
