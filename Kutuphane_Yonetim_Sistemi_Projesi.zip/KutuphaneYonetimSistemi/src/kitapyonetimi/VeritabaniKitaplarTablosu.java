package kitapyonetimi;

import veritabani.VeritabaniBaglantisi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VeritabaniKitaplarTablosu {

    public VeritabaniKitaplarTablosu() {
        tabloOlustur();
    }

    private void tabloOlustur() {
        String sql = "CREATE TABLE IF NOT EXISTS kitaplar (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "ad TEXT," +
                     "yazar TEXT," +
                     "tur TEXT," +
                     "yayin_yili TEXT)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Kitaplar tablosu oluşturulurken hata: " + e.getMessage());
        }
    }
}