package kullaniciyonetimi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class GirisYapma implements IGirisYapma{
	
	@Override
    public boolean girisYap(String kullaniciAdi, String sifre) {
        String sql = "SELECT * FROM kullanicilar WHERE kullanici_adi = ? AND sifre = ?";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, kullaniciAdi);
            pstmt.setString(2, sifre);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Giriş başarılı: " + kullaniciAdi);
                return true;
            } else {
                System.out.println("Giriş başarısız!");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Giriş yapılırken hata: " + e.getMessage());
            return false;
        }
    }

}
