package kullaniciyonetimi;

public interface IGirisYapma {
	boolean girisYap(String kullaniciAdi, String sifre);
}
