package kullaniciyonetimi;

public interface IKayitOlma {
	void kaydol(String kullaniciAdi, String sifre,String mailAdresi);
}
