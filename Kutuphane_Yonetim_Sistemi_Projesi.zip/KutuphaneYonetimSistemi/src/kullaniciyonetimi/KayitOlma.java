package kullaniciyonetimi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class KayitOlma implements IKayitOlma{
	
	@Override
    public void kaydol(String kullaniciAdi, String sifre, String mailAdresi) {
        String sql = "INSERT INTO kullanicilar(kullanici_adi, sifre, email) VALUES(?, ?, ?)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, kullaniciAdi);
            pstmt.setString(2, sifre);
            pstmt.setString(3, mailAdresi);
            pstmt.executeUpdate();
            System.out.println("Kullanıcı kaydedildi: " + kullaniciAdi);
        } catch (SQLException e) {
            System.out.println("Kullanıcı kaydedilirken hata: " + e.getMessage());
        }
    }
}
