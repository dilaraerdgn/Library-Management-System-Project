package kullaniciyonetimi;

import veritabani.VeritabaniBaglantisi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VeritabaniKullanicilarTablosu {

    public VeritabaniKullanicilarTablosu() {
        tabloOlustur();
    }

    private void tabloOlustur() {
        String sql = "CREATE TABLE IF NOT EXISTS kullanicilar (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "kullanici_adi TEXT UNIQUE," +
                     "sifre TEXT)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Tablo oluşturulurken hata: " + e.getMessage());
        }
    }
}
  