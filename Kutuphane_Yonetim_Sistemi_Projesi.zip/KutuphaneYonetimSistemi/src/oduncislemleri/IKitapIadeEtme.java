package oduncislemleri;

public interface IKitapIadeEtme {
	void kitapIadeEt(int oduncId);
}
