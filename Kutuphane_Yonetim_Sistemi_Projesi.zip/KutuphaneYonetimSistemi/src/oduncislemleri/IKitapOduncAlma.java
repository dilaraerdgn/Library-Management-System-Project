package oduncislemleri;

public interface IKitapOduncAlma {
	void kitapOduncAl(int kullaniciId, int kitapId);
}
