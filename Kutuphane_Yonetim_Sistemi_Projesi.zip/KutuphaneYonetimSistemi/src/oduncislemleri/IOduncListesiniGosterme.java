package oduncislemleri;

public interface IOduncListesiniGosterme {
	void oduncListesiniGoster();
}
