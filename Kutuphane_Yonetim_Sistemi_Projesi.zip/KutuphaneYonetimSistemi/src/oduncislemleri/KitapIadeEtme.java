package oduncislemleri;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import veritabani.VeritabaniBaglantisi;

public class KitapIadeEtme implements IKitapIadeEtme{
	
	@Override
    public void kitapIadeEt(int oduncId) {
        String sql = "UPDATE oduncler SET iade_tarihi = ? WHERE id = ?";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().toString());
            pstmt.setInt(2, oduncId);
            int guncellenenSatir = pstmt.executeUpdate();
            if (guncellenenSatir > 0) {
                System.out.println("Kitap iade edildi: Ödünç ID = " + oduncId);
            } else {
                System.out.println("İade edilecek ödünç kaydı bulunamadı: ID = " + oduncId);
            }
        } catch (SQLException e) {
            System.out.println("Kitap iade edilirken hata: " + e.getMessage());
        }
    }
}
