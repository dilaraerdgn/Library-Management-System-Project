package oduncislemleri;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import veritabani.VeritabaniBaglantisi;

public class KitapOduncAlma implements IKitapOduncAlma{
	
	@Override
    public void kitapOduncAl(int kullaniciId, int kitapId) {
        String sql = "INSERT INTO oduncler (kullanici_id, kitap_id, alis_tarihi) VALUES (?, ?, ?)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, kullaniciId);
            pstmt.setInt(2, kitapId);
            pstmt.setString(3, LocalDate.now().toString());
            pstmt.executeUpdate();
            System.out.println("Kitap ödünç alındı: Kullanıcı ID = " + kullaniciId + ", Kitap ID = " + kitapId);
        } catch (SQLException e) {
            System.out.println("Kitap ödünç alınırken hata: " + e.getMessage());
        }
    }
}
