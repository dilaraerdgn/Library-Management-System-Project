package oduncislemleri;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import veritabani.VeritabaniBaglantisi;

public class OduncListesiniGosterme implements IOduncListesiniGosterme{
	
	@Override
    public void oduncListesiniGoster() {
        String sql = "SELECT * FROM oduncler";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            boolean listeBosMu = true;
            while (rs.next()) {
                listeBosMu = false;
                System.out.println("Ödünç ID: " + rs.getInt("id") +
                                   ", Kullanıcı ID: " + rs.getInt("kullanici_id") +
                                   ", Kitap ID: " + rs.getInt("kitap_id") +
                                   ", Alış Tarihi: " + rs.getString("alis_tarihi") +
                                   ", İade Tarihi: " + rs.getString("iade_tarihi"));
            }
            if (listeBosMu) {
                System.out.println("Hiç ödünç kaydı bulunmamaktadır.");
            }
        } catch (SQLException e) {
            System.out.println("Ödünç listesi gösterilirken hata: " + e.getMessage());
        }
    }
}
