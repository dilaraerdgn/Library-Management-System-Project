package oduncislemleri;

import veritabani.VeritabaniBaglantisi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class VeritabaniOdunclarTablosu {

    public VeritabaniOdunclarTablosu() {
        tabloOlustur();
    }

    private void tabloOlustur() {
        String sql = "CREATE TABLE IF NOT EXISTS oduncler (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "kullanici_id INTEGER," +
                     "kitap_id INTEGER," +
                     "alis_tarihi TEXT," +
                     "iade_tarihi TEXT)";
        try (Connection conn = VeritabaniBaglantisi.baglantiAl();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Ödünçler tablosu oluşturulurken hata: " + e.getMessage());
        }
    }
}