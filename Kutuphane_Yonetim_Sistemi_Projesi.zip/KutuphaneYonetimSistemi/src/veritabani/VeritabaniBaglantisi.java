package veritabani;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class VeritabaniBaglantisi {
    private static final String URL = "jdbc:sqlite:kutuphane.db";

    public static Connection baglantiAl() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}