package com.kutuphane.kullanici_servisi.controller;

import com.kutuphane.kullanici_servisi.model.Kullanici;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/kullanicilar")
public class KullaniciController {

    @GetMapping("/{id}")
    public Kullanici getKullaniciById(@PathVariable Long id) {

        return new Kullanici(id, "Dilara Erdoğan", "dilara@gmail.com");
    }
}
//http://localhost:8080/api/kullanicilar/5
