package com.kutuphane.kullanici_servisi.model;

public class Kullanici {
    private Long id;
    private String ad;
    private String email;

    public Kullanici() {
    }

    public Kullanici(Long id, String ad, String email) {
        this.id = id;
        this.ad = ad;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
