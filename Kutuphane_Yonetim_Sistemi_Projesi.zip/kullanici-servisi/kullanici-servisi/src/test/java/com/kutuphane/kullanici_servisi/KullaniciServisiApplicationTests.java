package com.kutuphane.kullanici_servisi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KullaniciServisiApplicationTests {

	@Test
	void contextLoads() {
	}

}
